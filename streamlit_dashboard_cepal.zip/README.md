# Dashboard ECLAC
Visualización del riesgo comunal del personal en la Región Metropolitana.